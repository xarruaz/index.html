# JC Imóveis - Site institucional

Este é o site oficial da JC Imóveis, com foco em lotes à venda em São Francisco do Sul (SC).

## Publicação via GitHub Pages

1. Faça upload deste repositório no GitHub
2. Certifique-se de que o arquivo principal está nomeado como `index.html`
3. Vá em **Settings > Pages**
4. Ative o GitHub Pages selecionando:
   - Branch: `main`
   - Pasta: `/ (root)`

Seu site estará disponível em:
https://xarruaz.github.io/site-jc-imoveis
